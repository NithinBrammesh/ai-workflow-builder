import { NavLink, Outlet, useNavigate } from "react-router-dom";

import {
  FiActivity,
  FiBell,
  FiChevronDown,
  FiGitBranch,
  FiHome,
  FiLogOut,
  FiPlus,
  FiSettings,
  FiUser,
} from "react-icons/fi";

import "./Layout.css";

function Layout() {
  const navigate = useNavigate();

  const navigation = [
    {
      label: "Dashboard",
      path: "/dashboard",
      icon: <FiHome />,
    },
    {
      label: "Workflows",
      path: "/workflows",
      icon: <FiGitBranch />,
    },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-logo">
            <FiActivity />
          </div>

          <div>
            <div className="brand-title">FlowForge</div>
            <div className="brand-subtitle">AI Workflow Builder</div>
          </div>
        </div>

        <div className="sidebar-section-label">Workspace</div>

        <nav className="sidebar-nav">
          {navigation.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `nav-item ${isActive ? "active" : ""}`
              }
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-create">
          <button
            className="sidebar-create-button"
            onClick={() => navigate("/workflows/new")}
          >
            <FiPlus />
            <span>New Workflow</span>
          </button>
        </div>

        <div className="sidebar-bottom">
          <NavLink
            to="/dashboard"
            className="nav-item"
          >
            <span className="nav-icon">
              <FiSettings />
            </span>
            <span>Settings</span>
          </NavLink>

          <button
            className="nav-item logout-button"
            onClick={() => navigate("/login")}
          >
            <span className="nav-icon">
              <FiLogOut />
            </span>
            <span>Sign out</span>
          </button>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <span className="topbar-label">Organization</span>
            <span className="topbar-divider">/</span>
            <span className="topbar-current">Acme Support</span>
            <FiChevronDown className="topbar-chevron" />
          </div>

          <div className="topbar-right">
            <button className="icon-button" title="Notifications">
              <FiBell />
              <span className="notification-dot" />
            </button>

            <div className="user-menu">
              <div className="user-avatar">NB</div>

              <div className="user-info">
                <span className="user-name">Nithin B</span>
                <span className="user-role">Owner</span>
              </div>

              <FiChevronDown className="user-chevron" />
            </div>
          </div>
        </header>

        <main className="main-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export default Layout;