import { createClient } from "@nhost/nhost-js";

const nhost = createClient({
  subdomain: "vqvguejhcipfweukqyfu",
  region: "ap-south-1",
});

/**
 * Execute a workflow through the Nhost serverless function.
 *
 * The authenticated user's JWT is automatically attached
 * by the Nhost client.
 */
export async function runWorkflow(workflowId, input) {
  try {
    const response = await nhost.functions.post(
      "/workflow-execution",
      {
        workflow_id: workflowId,
        input,
      }
    );

    return response.body;
  } catch (error) {
    console.error("Workflow execution error:", error);

    throw new Error(
      error.message || "Failed to execute workflow"
    );
  }
}

/**
 * Approve a paused workflow step.
 *
 * IMPORTANT:
 * We intentionally do NOT send user_id.
 *
 * approve-step gets the authenticated user from
 * the Nhost JWT on the backend.
 */
export async function approveStep(stepRunId) {
  try {
    const response = await nhost.functions.post(
      "/approve-step",
      {
        step_run_id: stepRunId,
      }
    );

    return response.body;
  } catch (error) {
    console.error("Approval error:", error);

    throw new Error(
      error.message || "Failed to approve workflow"
    );
  }
}

export default nhost;