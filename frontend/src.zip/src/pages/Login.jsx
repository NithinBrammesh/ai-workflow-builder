import { useNavigate } from "react-router-dom";

import {
  FiArrowRight,
  FiEye,
  FiLock,
  FiMail,
  FiShield,
  FiZap,
} from "react-icons/fi";

import "./Login.css";

function Login() {
  const navigate = useNavigate();

  const handleLogin = (event) => {
    event.preventDefault();

    // Temporary frontend demo.
    // We will connect this to Nhost authentication later.
    navigate("/dashboard");
  };

  return (
    <div className="login-page">
      <div className="login-brand">
        <div className="login-brand-icon">
          <FiZap />
        </div>

        <span>FlowForge</span>
      </div>

      <div className="login-container">
        <div className="login-card">
          <div className="login-header">
            <div className="login-icon">
              <FiShield />
            </div>

            <h1>Welcome back</h1>

            <p>
              Sign in to manage your AI workflows and
              automation.
            </p>
          </div>

          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label htmlFor="email">
                Email address
              </label>

              <div className="input-wrapper">
                <FiMail />

                <input
                  id="email"
                  type="email"
                  placeholder="you@company.com"
                  defaultValue="nithin@example.com"
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <div className="password-label">
                <label htmlFor="password">
                  Password
                </label>

                <button type="button">
                  Forgot password?
                </button>
              </div>

              <div className="input-wrapper">
                <FiLock />

                <input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  defaultValue="password"
                  required
                />

                <FiEye className="input-action" />
              </div>
            </div>

            <button
              type="submit"
              className="login-button"
            >
              Sign in
              <FiArrowRight />
            </button>
          </form>

          <div className="login-footer">
            <span>Don't have an account?</span>
            <button type="button">
              Create account
            </button>
          </div>
        </div>

        <p className="login-security">
          <FiShield />
          Secure authentication powered by Nhost
        </p>
      </div>
    </div>
  );
}

export default Login;