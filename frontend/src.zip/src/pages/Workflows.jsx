import { useNavigate } from "react-router-dom";

import {
  FiFilter,
  FiGitBranch,
  FiPlus,
  FiSearch,
} from "react-icons/fi";

import WorkflowCard from "../components/WorkflowCard";

import "./Workflows.css";

const workflows = [
  {
    id: "2c29989c-1556-4eda-aeb1-816417c6b9ce",
    name: "Customer Support Workflow",
    description:
      "Classify customer requests, fetch external data and route orders for approval.",
    steps: 7,
    status: "Active",
    updated: "2 minutes ago",
  },
  {
    id: "order-processing",
    name: "Order Processing",
    description:
      "Automate incoming orders with validation, approval and database updates.",
    steps: 6,
    status: "Active",
    updated: "Yesterday",
  },
  {
    id: "invoice-automation",
    name: "Invoice Automation",
    description:
      "Process invoice requests and notify the finance team when complete.",
    steps: 5,
    status: "Active",
    updated: "2 days ago",
  },
];

function Workflows() {
  const navigate = useNavigate();

  return (
    <div className="page-container workflows-page">
      <div className="page-header">
        <div>
          <h1 className="page-title">
            Workflows
          </h1>

          <p className="page-description">
            Build, manage and execute your AI-powered
            workflows.
          </p>
        </div>

        <button
          className="btn btn-primary"
          onClick={() => navigate("/workflows/new")}
        >
          <FiPlus />
          New Workflow
        </button>
      </div>

      <div className="workflow-toolbar">
        <div className="workflow-search">
          <FiSearch />

          <input
            type="text"
            placeholder="Search workflows..."
          />
        </div>

        <button className="filter-button">
          <FiFilter />
          Filter
        </button>
      </div>

      <div className="workflow-summary">
        <div className="workflow-summary-title">
          <FiGitBranch />
          <strong>All workflows</strong>
          <span>{workflows.length}</span>
        </div>
      </div>

      <div className="workflow-grid">
        {workflows.map((workflow) => (
          <WorkflowCard
            key={workflow.id}
            workflow={workflow}
          />
        ))}
      </div>
    </div>
  );
}

export default Workflows;