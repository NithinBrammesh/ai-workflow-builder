import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  FiArrowLeft,
  FiCheck,
  FiChevronDown,
  FiGlobe,
  FiPlus,
  FiSave,
  FiShield,
  FiCpu,
  FiDatabase,
  FiGitBranch,
  FiMessageCircle,
  FiPlay,
  FiSettings,
} from "react-icons/fi";

import StepNode from "../components/StepNode";

import "./WorkflowBuilder.css";

const workflowSteps = [
  {
    id: "1",
    name: "Receive Customer Request",
    type: "input",
    description: "Accept incoming customer request.",
  },
  {
    id: "2",
    name: "Classify Request",
    type: "ai",
    description: "Classify request into a support category.",
  },
  {
    id: "3",
    name: "Fetch External Data",
    type: "http_request",
    description: "Retrieve additional information from an API.",
  },
  {
    id: "4",
    name: "Order Branch",
    type: "conditional_branch",
    description: "Check whether the request is an order.",
  },
  {
    id: "5",
    name: "Manager Approval",
    type: "approval_gate",
    description: "Wait for an authorized manager.",
  },
  {
    id: "6",
    name: "Save Workflow Result",
    type: "db_write",
    description: "Save the workflow result.",
  },
  {
    id: "7",
    name: "Notify Customer Support",
    type: "notify",
    description: "Send completion notification.",
  },
];

const stepTypes = [
  {
    type: "input",
    name: "Input",
    icon: FiPlay,
  },
  {
    type: "ai",
    name: "AI",
    icon: FiCpu,
  },
  {
    type: "http_request",
    name: "HTTP",
    icon: FiGlobe,
  },
  {
    type: "conditional_branch",
    name: "Condition",
    icon: FiGitBranch,
  },
  {
    type: "approval_gate",
    name: "Approval",
    icon: FiShield,
  },
  {
    type: "db_write",
    name: "Database",
    icon: FiDatabase,
  },
  {
    type: "notify",
    name: "Notify",
    icon: FiMessageCircle,
  },
];

function WorkflowBuilder() {
  const navigate = useNavigate();
  const { workflowId } = useParams();

  const [selectedStep, setSelectedStep] =
    useState(workflowSteps[1]);

  const isNew = !workflowId;

  return (
    <div className="builder-page">
      <div className="builder-header">
        <div className="builder-header-left">
          <button
            className="builder-back"
            onClick={() => navigate("/workflows")}
          >
            <FiArrowLeft />
          </button>

          <div>
            <div className="builder-breadcrumb">
              Workflows
              <span>/</span>
              {isNew
                ? "New Workflow"
                : "Customer Support Workflow"}
            </div>

            <h1>
              {isNew
                ? "New Workflow"
                : "Customer Support Workflow"}
            </h1>
          </div>
        </div>

        <div className="builder-header-actions">
          <button className="btn btn-secondary">
            <FiSettings />
            Settings
          </button>

          <button className="btn btn-secondary">
            <FiSave />
            Save
          </button>

          <button
            className="btn btn-primary"
            onClick={() =>
              navigate(
                `/workflows/${workflowId || "demo"}/run/demo-run`
              )
            }
          >
            <FiPlay />
            Run Workflow
          </button>
        </div>
      </div>

      <div className="builder-layout">
        <aside className="step-library">
          <div className="builder-panel-title">
            <div>
              <h2>Step Library</h2>
              <p>Choose a step to add.</p>
            </div>
          </div>

          <div className="step-library-list">
            {stepTypes.map((item) => {
              const Icon = item.icon;

              return (
                <button
                  className="library-step"
                  key={item.type}
                >
                  <span className="library-step-icon">
                    <Icon />
                  </span>

                  <span>
                    <strong>{item.name}</strong>
                    <small>{item.type}</small>
                  </span>

                  <FiPlus />
                </button>
              );
            })}
          </div>
        </aside>

        <section className="workflow-canvas">
          <div className="canvas-toolbar">
            <div>
              <span className="canvas-status">
                <span />
                Draft
              </span>

              <span className="canvas-meta">
                {workflowSteps.length} steps
              </span>
            </div>

            <div className="canvas-toolbar-actions">
              <button>
                <FiChevronDown />
                Auto layout
              </button>
            </div>
          </div>

          <div className="canvas-content">
            <div className="canvas-title">
              <div className="canvas-title-icon">
                <FiGitBranch />
              </div>

              <div>
                <h2>Customer Support Workflow</h2>
                <p>
                  Customer request automation
                </p>
              </div>
            </div>

            <div className="steps-flow">
              {workflowSteps.map((step, index) => (
                <StepNode
                  key={step.id}
                  step={step}
                  index={index}
                  selected={
                    selectedStep?.id === step.id
                  }
                  status={
                    index < 4
                      ? "completed"
                      : index === 4
                        ? "paused"
                        : "pending"
                  }
                  onClick={() =>
                    setSelectedStep(step)
                  }
                />
              ))}
            </div>
          </div>
        </section>

        <aside className="step-config">
          <div className="builder-panel-title">
            <div>
              <h2>Configuration</h2>
              <p>Configure selected step.</p>
            </div>
          </div>

          {selectedStep && (
            <div className="config-content">
              <div className="config-step-header">
                <div className="config-step-icon">
                  {selectedStep.type === "ai" ? (
                    <FiCpu />
                  ) : selectedStep.type ===
                    "http_request" ? (
                    <FiGlobe />
                  ) : selectedStep.type ===
                    "approval_gate" ? (
                    <FiShield />
                  ) : selectedStep.type ===
                    "db_write" ? (
                    <FiDatabase />
                  ) : (
                    <FiGitBranch />
                  )}
                </div>

                <div>
                  <span>Selected step</span>
                  <strong>
                    {selectedStep.name}
                  </strong>
                </div>
              </div>

              <div className="config-divider" />

              <div className="config-field">
                <label>Step name</label>
                <input
                  value={selectedStep.name}
                  readOnly
                />
              </div>

              <div className="config-field">
                <label>Step type</label>

                <div className="config-select">
                  {selectedStep.type}
                  <FiChevronDown />
                </div>
              </div>

              <div className="config-field">
                <label>Description</label>

                <textarea
                  value={
                    selectedStep.description || ""
                  }
                  readOnly
                  rows="4"
                />
              </div>

              <div className="config-info">
                <FiCheck />

                <div>
                  <strong>Step ready</strong>
                  <span>
                    This step is configured and ready
                    for execution.
                  </span>
                </div>
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

export default WorkflowBuilder;